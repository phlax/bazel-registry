// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "quiche/http2/hpack/http2_hpack_constants.h"

#include <sstream>

#include "quiche/common/platform/api/quiche_logging.h"
#include "quiche/common/platform/api/quiche_test.h"

namespace http2 {
namespace test {
namespace {

TEST(HpackEntryTypeTest, HpackEntryTypeToString) {
  EXPECT_EQ("kIndexedHeader",
            HpackEntryTypeToString(HpackEntryType::kIndexedHeader));
  EXPECT_EQ("kDynamicTableSizeUpdate",
            HpackEntryTypeToString(HpackEntryType::kDynamicTableSizeUpdate));
  EXPECT_EQ("kIndexedLiteralHeader",
            HpackEntryTypeToString(HpackEntryType::kIndexedLiteralHeader));
  EXPECT_EQ("kUnindexedLiteralHeader",
            HpackEntryTypeToString(HpackEntryType::kUnindexedLiteralHeader));
  EXPECT_EQ("kNeverIndexedLiteralHeader",
            HpackEntryTypeToString(HpackEntryType::kNeverIndexedLiteralHeader));
  EXPECT_EQ("UnknownHpackEntryType(123)",
            HpackEntryTypeToString(static_cast<HpackEntryType>(123)));
}

TEST(HpackEntryTypeTest, OutputHpackEntryType) {
  {
    std::stringstream log;
    log << HpackEntryType::kIndexedHeader;
    EXPECT_EQ("kIndexedHeader", log.str());
  }
  {
    std::stringstream log;
    log << HpackEntryType::kDynamicTableSizeUpdate;
    EXPECT_EQ("kDynamicTableSizeUpdate", log.str());
  }
  {
    std::stringstream log;
    log << HpackEntryType::kIndexedLiteralHeader;
    EXPECT_EQ("kIndexedLiteralHeader", log.str());
  }
  {
    std::stringstream log;
    log << HpackEntryType::kUnindexedLiteralHeader;
    EXPECT_EQ("kUnindexedLiteralHeader", log.str());
  }
  {
    std::stringstream log;
    log << HpackEntryType::kNeverIndexedLiteralHeader;
    EXPECT_EQ("kNeverIndexedLiteralHeader", log.str());
  }
  {
    std::stringstream log;
    log << static_cast<HpackEntryType>(124);
    EXPECT_EQ("UnknownHpackEntryType(124)", log.str());
  }
}

}  // namespace
}  // namespace test
}  // namespace http2
